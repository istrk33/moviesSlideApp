'use strict'

module.exports = (data, _props, event) => {
    data.navigation="homeWithOverlay";
    return data
}